package ke.co.skyworld.utils.http;

import io.undertow.Handlers;
import io.undertow.server.handlers.resource.ClassPathResourceManager;
import io.undertow.server.handlers.resource.ResourceHandler;

/**
 * sls-api (ke.co.scedar.utils.http)
 * Created by: elon
 * On: 30 Jun, 2018 6/30/18 11:17 PM
 **/
public class ScedarResourceHandlers {

    /*public static ResourceHandler getPortal(){
        return Handlers.resource(
                new ClassPathResourceManager(
                        PortalPkgLocator.class.getClassLoader(), PortalPkgLocator.class.getPackage()))
                .addWelcomeFiles("index.html");
    }*/

}