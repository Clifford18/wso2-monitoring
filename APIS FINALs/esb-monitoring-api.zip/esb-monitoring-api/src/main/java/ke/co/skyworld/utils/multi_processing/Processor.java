package ke.co.skyworld.utils.multi_processing;

public class Processor {
}
